export default (
  '<div class="cropper-container">' +
    '<div class="cropper-wrap-box">' +
      '<div class="cropper-canvas"></div>' +
    '</div>' +
    '<div class="cropper-drag-box"></div>' +
    '<div class="cropper-crop-box">' +
      '<span class="cropper-view-box"></span>' +
      '<span class="cropper-dashed dashed-h"></span>' +
      '<span class="cropper-dashed dashed-v"></span>' +
      '<span class="cropper-center"></span>' +
      '<span class="cropper-face"></span>' +
      '<span class="cropper-line line-e" data-action="e"></span>' +
      '<span class="cropper-line line-n" data-action="n"></span>' +
      '<span class="cropper-line line-w" data-action="w"></span>' +
      '<span class="cropper-line line-s" data-action="s"></span>' +
      '<span class="cropper-point point-e" data-action="e"></span>' +
      '<span class="cropper-point point-n" data-action="n"></span>' +
      '<span class="cropper-point point-w" data-action="w"></span>' +
      '<span class="cropper-point point-s" data-action="s"></span>' +
      '<span class="cropper-point point-ne" data-action="ne"></span>' +
      '<span class="cropper-point point-nw" data-action="nw"></span>' +
      '<span class="cropper-point point-sw" data-action="sw"></span>' +
      '<span class="cropper-point point-se" data-action="se"></span>' +
    '</div>' +
  '</div>'
);
